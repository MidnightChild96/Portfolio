import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;;

public class Radix {
    public static void main(String[] args) {
        // messages claiming this is my work
        System.out.println("Kevin Nguyen (nguyenk10@csp.edu)");
        System.out.println("I confirm this project was worked only by me for CSC 420");
        // sets file to be read
        File file = new File("words.txt");
        // variables to be used
        String[] array = new String[6];
        String line;
        int i = 0;
        try {
            // scanner to read the file
            Scanner sc = new Scanner(file);
            // loops through each line of the file
            while (sc.hasNextLine()) {
                line = sc.nextLine();
                // each line is split on the | symbol
                array[i] = line.toLowerCase();
                i++;
            }
            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Radix sort
        radixSort(array);
    }

    // radix sort based on index
    public static void radixSort(String[] array) {
        // loops through the first 20 characters
        for (int i = 19; i >= 0; i--) {
            // Prints out the current index
            System.out.println("Index " + i);
            // bucket sort based on the current index
            bucketSort(array, i);
            // loops through list printing the current array
            for (int j = 0; j < array.length; j++) {
                System.out.println(array[j]);
            }
            // Just a line break for easier readability
            System.out.println();
        }
    }

    // bucket sort for buckets
    public static void bucketSort(String[] array, int n) {
        // Used an array of ArrayList since it will add nodes in order so first in first
        // out
        ArrayList<String>[] bucket = new ArrayList[27];
        // Index of an array
        int k = 0;

        // loop to sort into buckets
        for (int i = 0; i < array.length; i++) {
            // if string is shorter than the index it will go in the 26th index of the
            // array
            if (array[i].length() - 1 < n) {
                // creates an ArrayList if it doesn't exist
                if (bucket[26] == null) {
                    bucket[26] = new ArrayList<>();
                }
                // Appends to Arraylist if it is shorter than the inputted index
                bucket[26].add(array[i]);
            } else {
                // if the char is empty space it will append to the 26th index of the array
                if (array[i].charAt(n) == ' ') {
                    // will create ArrayList if empty
                    if (bucket[26] == null) {
                        bucket[26] = new ArrayList<>();
                    }
                    // appends to ArrayList if it is empty space
                    bucket[26].add(array[i]);
                } else {
                    // subtracts char from the 'a' value and indexes it into a bucket
                    // creates an ArrayList if it doesn't exist
                    if (bucket[array[i].charAt(n) - 'a'] == null) {
                        bucket[array[i].charAt(n) - 'a'] = new ArrayList<>();
                    }
                    // appends to ArrayList for the according letter
                    bucket[array[i].charAt(n) - 'a'].add(array[i]);
                }
            }
        }
        // if the 26th index is empty then it won't trigger as it's used only for too
        // short of strings or empty space
        if (bucket[26] != null) {
            // loops through entire array placing short or empty space strings first
            for (int i = 0; i < bucket[26].size(); i++) {
                array[k++] = bucket[26].get(i);
            }
        }
        // loops through entire array in alphabetical order and puts them in the array
        for (int i = 0; i < 26; i++) {
            if (bucket[i] != null) {
                for (int j = 0; j < bucket[i].size(); j++) {
                    array[k++] = bucket[i].get(j);
                }
            }
        }
    }
}
